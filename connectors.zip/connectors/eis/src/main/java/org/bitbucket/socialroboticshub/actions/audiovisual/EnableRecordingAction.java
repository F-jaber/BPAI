package org.bitbucket.socialroboticshub.actions.audiovisual;

public class EnableRecordingAction extends DialogflowRecordingAction {
	public final static String NAME = "enableRecording";

	public EnableRecordingAction() {
		super(true);
	}
}
