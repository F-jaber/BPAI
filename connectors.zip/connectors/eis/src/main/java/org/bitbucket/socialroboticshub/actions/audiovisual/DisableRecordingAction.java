package org.bitbucket.socialroboticshub.actions.audiovisual;

public class DisableRecordingAction extends DialogflowRecordingAction {
	public final static String NAME = "disableRecording";

	public DisableRecordingAction() {
		super(false);
	}
}
